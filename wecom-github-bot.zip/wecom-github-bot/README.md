# 企微 @ 干活机器人

同事在企业微信（群里 @ 或单聊）给机器人发任务 → 机器人用 Claude Code 在仓库里干活 → 自动建分支、提交、推送、开 PR → 把结果回复给同事。任务进 SQLite 队列，多 worker 并发，进程崩溃/重启后继续干。

```
企微 @机器人 ──► /wecom/callback（验签+解密，秒回“已入队”）
                     │
                  SQLite 队列 ◄── 重启自动恢复
                     │
        worker × N：git worktree → claude -p 干活 → commit/push → 开 PR
                     │
              response_url 回复结果（含 PR 链接）
```

## 部署步骤

1. **企微侧**：管理后台 → 应用管理 → 智能机器人 → 创建 → 选 **API 模式**。
   - 接收消息 URL 填 `https://你的域名/wecom/callback`
   - 随机生成 Token 和 EncodingAESKey，填进 `.env`
   - 先启动服务再点“保存”（保存时企微会发 GET 验证，需 1 秒内响应）
   - 把机器人加进需要的群
   > 注意：普通「群机器人 webhook」只能发消息、收不到 @，必须用智能机器人。
2. **GitHub 侧**：建一个 fine-grained PAT，只授权目标仓库，权限 `Contents: Read and write` + `Pull requests: Read and write`。
3. `cp .env.example .env`，填好各项（含 `ANTHROPIC_API_KEY`）。
4. 需要公网 HTTPS 入口（云服务器 + 反代，或 Cloudflare Tunnel / ngrok 先试）。
5. `docker compose up -d --build`，`curl localhost:8000/healthz` 检查。

## 使用

- `@机器人 给 README 补一个本地启动说明`
- `@机器人 repo=acme/backend 修复登录接口空指针`
- `@机器人 状态` / `@机器人 帮助`

## 设计取舍与安全

- **只提 PR，不直接改主分支**，由人 review 合并。如需自动合并，在 `gitops.publish` 后加 GitHub merge API 调用即可。
- agent 在容器内以普通用户运行，用 `--dangerously-skip-permissions` 才能无人值守，**务必只在 Docker 里跑**，且 PAT 最小权限。
- GitHub token 只通过 `git -c http.extraHeader` 传入，不写入 .git/config，也不进 agent 环境变量。
- `ALLOWED_REPOS` / `ALLOWED_USERS` 用来限制谁能让机器人动哪些仓库，建议必填。
- 回复用的 `response_url` 每条消息只能用一次、约 1 小时有效，所以任务期间只发“已入队”，完成时发一条最终结果；超过 1 小时的任务回复会失败（可改成群机器人 webhook 兜底）。

## 已验证 / 未验证

- ✅ 加解密/签名的自测通过（`python test_crypto.py`）。
- ⚠️ 我这里没有公网和企微环境，没法端到端联调。接入时如遇到字段差异，对照官方文档调整 `app/main.py`：
  <https://developer.work.weixin.qq.com/document/path/100719>（接收消息）
  <https://developer.work.weixin.qq.com/document/path/101033>（加解密）
