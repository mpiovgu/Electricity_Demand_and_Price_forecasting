import base64, json, os
from app.wecrypto import WeComCrypto
key = base64.b64encode(os.urandom(32)).decode().rstrip("=")
c = WeComCrypto("tok", key)
r = c.encrypt_reply(json.dumps({"hi": "你好"}, ensure_ascii=False))
out = c.decrypt_msg(r["msgsignature"], r["timestamp"], r["nonce"], r["encrypt"])
assert json.loads(out)["hi"] == "你好"
print("crypto roundtrip OK")
