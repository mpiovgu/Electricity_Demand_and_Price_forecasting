"""SQLite 持久化任务队列:进程重启不丢活。"""
import sqlite3
import threading
import time

from .config import settings

_lock = threading.Lock()
_conn: sqlite3.Connection | None = None


def init():
    global _conn
    import os

    os.makedirs(settings.data_dir, exist_ok=True)
    _conn = sqlite3.connect(f"{settings.data_dir}/bot.db", check_same_thread=False)
    _conn.row_factory = sqlite3.Row
    _conn.execute(
        """CREATE TABLE IF NOT EXISTS jobs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        msgid TEXT UNIQUE, userid TEXT, chatid TEXT, response_url TEXT,
        repo TEXT, task TEXT, status TEXT, result TEXT,
        created REAL, started REAL, finished REAL)"""
    )
    # 上次崩溃时还在跑的任务重新排队
    _conn.execute("UPDATE jobs SET status='queued' WHERE status='running'")
    _conn.commit()


def enqueue(msgid, userid, chatid, response_url, repo, task) -> int | None:
    with _lock:
        try:
            cur = _conn.execute(
                "INSERT INTO jobs(msgid,userid,chatid,response_url,repo,task,status,created)"
                " VALUES(?,?,?,?,?,?, 'queued', ?)",
                (msgid, userid, chatid, response_url, repo, task, time.time()),
            )
            _conn.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:  # 企微重试推送 -> 重复 msgid
            return None


def claim() -> sqlite3.Row | None:
    with _lock:
        row = _conn.execute(
            "SELECT * FROM jobs WHERE status='queued' ORDER BY id LIMIT 1"
        ).fetchone()
        if not row:
            return None
        _conn.execute(
            "UPDATE jobs SET status='running', started=? WHERE id=?", (time.time(), row["id"])
        )
        _conn.commit()
        return row


def finish(job_id: int, status: str, result: str):
    with _lock:
        _conn.execute(
            "UPDATE jobs SET status=?, result=?, finished=? WHERE id=?",
            (status, result, time.time(), job_id),
        )
        _conn.commit()


def stats() -> dict:
    with _lock:
        rows = _conn.execute("SELECT status, COUNT(*) c FROM jobs GROUP BY status").fetchall()
    return {r["status"]: r["c"] for r in rows}
