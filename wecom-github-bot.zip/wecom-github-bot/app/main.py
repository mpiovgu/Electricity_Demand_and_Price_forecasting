import json
import logging
import re
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse, PlainTextResponse

from . import db, worker
from .config import settings
from .wecrypto import CryptoError, WeComCrypto

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
log = logging.getLogger("main")
crypto = WeComCrypto(settings.wecom_token, settings.wecom_aes_key)

HELP = (
    "我是干活机器人 🤖\n"
    "用法: @我 + 你要做的事,例如:\n"
    "  @我 给 README 补一个本地启动说明\n"
    "  @我 repo=acme/backend 修复登录接口空指针\n"
    "做完会提 PR 并回复你。发送「状态」查看队列。"
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init()
    worker.start()
    yield
    worker.stop()


app = FastAPI(lifespan=lifespan)


def reply_text(text: str) -> JSONResponse:
    plain = json.dumps({"msgtype": "text", "text": {"content": text}}, ensure_ascii=False)
    return JSONResponse(crypto.encrypt_reply(plain))


@app.get("/healthz")
def healthz():
    return {"ok": True, "jobs": db.stats()}


@app.get("/wecom/callback")
def verify(msg_signature: str, timestamp: str, nonce: str, echostr: str):
    try:
        return PlainTextResponse(crypto.verify_url(msg_signature, timestamp, nonce, echostr))
    except CryptoError as e:
        log.warning("URL 验证失败: %s", e)
        return PlainTextResponse("forbidden", status_code=403)


@app.post("/wecom/callback")
async def callback(request: Request, msg_signature: str, timestamp: str, nonce: str):
    try:
        encrypt = (await request.json())["encrypt"]
        msg = json.loads(crypto.decrypt_msg(msg_signature, timestamp, nonce, encrypt))
    except Exception as e:
        log.warning("回调解密失败: %s", e)
        return PlainTextResponse("forbidden", status_code=403)

    if msg.get("msgtype") not in ("text", "mixed"):
        return Response(content="")  # 其它消息类型暂不处理
    if msg.get("msgtype") == "text":
        content = msg["text"]["content"]
    else:  # 图文混排:只取文字部分
        content = " ".join(i.get("text", {}).get("content", "")
                           for i in msg["mixed"]["msg_item"] if i.get("msgtype") == "text")
    task = re.sub(r"@\S+\s*", "", content, count=1).strip() if content.lstrip().startswith("@") else content.strip()
    userid = msg.get("from", {}).get("userid", "unknown")

    if settings.allowed_users and userid not in settings.allowed_users:
        return reply_text("抱歉,你还没有使用权限,请联系管理员。")
    if not task or task in ("帮助", "help", "?"):
        return reply_text(HELP)
    if task in ("状态", "status"):
        return reply_text(f"队列状态: {db.stats()}")

    m = re.search(r"repo=([\w.-]+/[\w.-]+)", task)
    repo = m.group(1) if m else settings.default_repo
    task = re.sub(r"repo=\S+", "", task).strip()
    if not repo:
        return reply_text("没有指定仓库,请加上 repo=owner/name")
    if settings.allowed_repos and repo not in settings.allowed_repos:
        return reply_text(f"仓库 {repo} 不在允许列表内。")
    if not task:
        return reply_text(HELP)

    job_id = db.enqueue(msg.get("msgid"), userid, msg.get("chatid", ""),
                        msg.get("response_url", ""), repo, task)
    if job_id is None:  # 企微重试
        return Response(content="")
    log.info("新任务 #%s from %s repo=%s: %s", job_id, userid, repo, task)
    return reply_text(f"收到,任务 #{job_id} 已入队 → {repo}\n干完提 PR 通知你 💪")
