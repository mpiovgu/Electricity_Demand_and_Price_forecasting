import logging
import threading

import httpx

from . import agent, db, gitops
from .config import settings

log = logging.getLogger("worker")
_stop = threading.Event()


def notify(job, text: str):
    """通过消息自带的 response_url 回复(该 URL 只能用一次,有效期约 1 小时)。"""
    try:
        r = httpx.post(job["response_url"],
                       json={"msgtype": "markdown", "markdown": {"content": text[:3500]}}, timeout=15)
        if r.status_code >= 300:
            log.warning("response_url 回复失败 %s %s", r.status_code, r.text[:200])
    except Exception:
        log.exception("response_url 回复异常")


def run_job(job):
    repo, task, user = job["repo"], job["task"], job["userid"]
    wt = None
    try:
        wt, branch, base = gitops.prepare(repo, job["id"], task)
        summary = agent.run(task, user, wt)
        body = f"由 @{user} 在企业微信发起\n\n**任务**: {task}\n\n**结果**:\n{summary}"
        pr = gitops.publish(repo, wt, branch, base, f"[bot] {task}", body)
        if pr:
            msg = f"✅ <@{user}> 搞定了\n> {task}\n\n{summary}\n\n🔗 [查看 PR]({pr})"
        else:
            msg = f"✅ <@{user}> 处理完了(没有代码改动)\n> {task}\n\n{summary}"
        db.finish(job["id"], "done", pr or summary[:500])
    except Exception as e:
        log.exception("job %s 失败", job["id"])
        db.finish(job["id"], "failed", str(e)[:500])
        msg = f"❌ <@{user}> 任务失败\n> {task}\n\n原因: {str(e)[:500]}"
    finally:
        if wt:
            gitops.cleanup(repo, wt)
    notify(job, msg)


def _loop(name: str):
    while not _stop.is_set():
        job = db.claim()
        if job is None:
            _stop.wait(2)
            continue
        log.info("[%s] 开工 job=%s repo=%s", name, job["id"], job["repo"])
        run_job(job)


def start():
    for i in range(settings.workers):
        threading.Thread(target=_loop, args=(f"w{i}",), daemon=True).start()


def stop():
    _stop.set()
