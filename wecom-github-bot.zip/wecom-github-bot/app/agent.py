"""用 Claude Code 无头模式干活。需要 ANTHROPIC_API_KEY;建议只在 Docker 容器里跑。"""
import os
import subprocess

from .config import settings

SYSTEM = (
    "你是公司同事在企业微信里 @ 来干活的工程助手。只在当前目录(一个 git 工作区)内工作。"
    "不要执行 git commit/push,也不要访问与任务无关的外部服务,提交由外层流程负责。"
    "完成后用中文给出简明结论:改了什么、如何验证、有什么需要人工确认的地方。"
    "如果任务无法完成或需求不清,不要乱改,直接说明原因。"
)


def run(task: str, userid: str, cwd) -> str:
    cmd = [settings.claude_bin, "-p", f"请求人: {userid}\n任务: {task}",
           "--append-system-prompt", SYSTEM,
           "--dangerously-skip-permissions", "--output-format", "text"]
    if settings.claude_model:
        cmd += ["--model", settings.claude_model]
    # 不把 GitHub token 暴露给 agent
    env = {k: v for k, v in os.environ.items() if k not in ("GITHUB_TOKEN", "WECOM_TOKEN", "WECOM_ENCODING_AES_KEY")}
    p = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True,
                       timeout=settings.task_timeout)
    out = (p.stdout or "").strip()
    if p.returncode != 0 and not out:
        raise RuntimeError(f"agent 退出码 {p.returncode}: {(p.stderr or '')[:500]}")
    return out or "(agent 没有输出)"
