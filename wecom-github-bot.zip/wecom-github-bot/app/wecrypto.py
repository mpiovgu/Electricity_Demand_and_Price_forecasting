"""企微回调加解密(与官方 WXBizMsgCrypt 一致)。智能机器人场景 receiveid 为空字符串。"""
import base64
import hashlib
import os
import secrets
import socket
import struct
import time

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


class CryptoError(Exception):
    pass


class WeComCrypto:
    def __init__(self, token: str, encoding_aes_key: str, receive_id: str = ""):
        if len(encoding_aes_key) != 43:
            raise CryptoError("EncodingAESKey 必须是 43 位")
        self.token = token
        self.key = base64.b64decode(encoding_aes_key + "=")
        self.receive_id = receive_id

    def signature(self, timestamp: str, nonce: str, encrypt: str) -> str:
        raw = "".join(sorted([self.token, timestamp, nonce, encrypt]))
        return hashlib.sha1(raw.encode()).hexdigest()

    def _verify(self, sig: str, timestamp: str, nonce: str, encrypt: str):
        if not secrets.compare_digest(sig, self.signature(timestamp, nonce, encrypt)):
            raise CryptoError("签名校验失败")

    def _decrypt(self, encrypt: str) -> str:
        c = Cipher(algorithms.AES(self.key), modes.CBC(self.key[:16]))
        d = c.decryptor()
        data = d.update(base64.b64decode(encrypt)) + d.finalize()
        data = data[: -data[-1]]  # PKCS7 (block 32)
        msg_len = struct.unpack(">I", data[16:20])[0]
        msg = data[20 : 20 + msg_len]
        rid = data[20 + msg_len :].decode()
        if rid != self.receive_id:
            raise CryptoError("receiveid 不匹配")
        return msg.decode()

    def _encrypt(self, msg: str) -> str:
        body = msg.encode()
        raw = os.urandom(16) + struct.pack(">I", len(body)) + body + self.receive_id.encode()
        pad = 32 - len(raw) % 32
        raw += bytes([pad]) * pad
        e = Cipher(algorithms.AES(self.key), modes.CBC(self.key[:16])).encryptor()
        return base64.b64encode(e.update(raw) + e.finalize()).decode()

    # --- 对外接口 ---
    def verify_url(self, sig: str, timestamp: str, nonce: str, echostr: str) -> str:
        self._verify(sig, timestamp, nonce, echostr)
        return self._decrypt(echostr)

    def decrypt_msg(self, sig: str, timestamp: str, nonce: str, encrypt: str) -> str:
        self._verify(sig, timestamp, nonce, encrypt)
        return self._decrypt(encrypt)

    def encrypt_reply(self, plaintext_json: str) -> dict:
        ts, nonce = str(int(time.time())), secrets.token_hex(8)
        enc = self._encrypt(plaintext_json)
        return {
            "encrypt": enc,
            "msgsignature": self.signature(ts, nonce, enc),
            "timestamp": ts,
            "nonce": nonce,
        }
