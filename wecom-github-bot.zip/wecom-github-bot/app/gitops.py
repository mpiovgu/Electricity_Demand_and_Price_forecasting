"""每个任务一个独立 git worktree,互不干扰;token 只通过命令行 header 传入,不落盘、不进 agent 环境。"""
import base64
import re
import shutil
import subprocess
import threading
from pathlib import Path

import httpx

from .config import settings

_repo_locks: dict[str, threading.Lock] = {}
_guard = threading.Lock()


def _lock_for(repo: str) -> threading.Lock:
    with _guard:
        return _repo_locks.setdefault(repo, threading.Lock())


def _auth_args() -> list[str]:
    b = base64.b64encode(f"x-access-token:{settings.github_token}".encode()).decode()
    return ["-c", f"http.extraHeader=Authorization: Basic {b}"]


def git(args: list[str], cwd: str | Path, auth=False, check=True) -> str:
    cmd = ["git", "-c", f"user.name={settings.git_user_name}",
           "-c", f"user.email={settings.git_user_email}"]
    if auth:
        cmd += _auth_args()
    p = subprocess.run(cmd + args, cwd=cwd, capture_output=True, text=True, timeout=600)
    if check and p.returncode != 0:
        err = p.stderr.replace(settings.github_token, "***") if settings.github_token else p.stderr
        raise RuntimeError(f"git {' '.join(args[:2])} 失败: {err.strip()[:500]}")
    return p.stdout.strip()


def _bare(repo: str) -> Path:
    return Path(settings.data_dir) / "repos" / (repo.replace("/", "__") + ".git")


def prepare(repo: str, job_id: int, task: str) -> tuple[Path, str, str]:
    """返回 (worktree 路径, 新分支名, base 分支名)"""
    bare = _bare(repo)
    slug = re.sub(r"[^a-z0-9]+", "-", task.lower())[:30].strip("-") or "task"
    branch = f"bot/{job_id}-{slug}"
    wt = Path(settings.data_dir) / "work" / f"job-{job_id}"
    with _lock_for(repo):
        if not bare.exists():
            bare.parent.mkdir(parents=True, exist_ok=True)
            git(["clone", "--bare", f"https://github.com/{repo}.git", str(bare)],
                cwd=bare.parent, auth=True)
        git(["fetch", "origin", "+refs/heads/*:refs/heads/*", "--prune"], cwd=bare, auth=True)
        base = git(["symbolic-ref", "--short", "HEAD"], cwd=bare)
        if wt.exists():
            shutil.rmtree(wt, ignore_errors=True)
            git(["worktree", "prune"], cwd=bare, check=False)
        git(["worktree", "add", "-B", branch, str(wt), base], cwd=bare)
    return wt, branch, base


def publish(repo: str, wt: Path, branch: str, base: str, title: str, body: str) -> str | None:
    """有改动就 commit + push + 开 PR,返回 PR 链接;无改动返回 None"""
    git(["add", "-A"], cwd=wt)
    if git(["status", "--porcelain"], cwd=wt):
        git(["commit", "-m", title[:72]], cwd=wt)
    if int(git(["rev-list", "--count", f"{base}..HEAD"], cwd=wt) or 0) == 0:
        return None
    git(["push", "-u", "origin", branch], cwd=wt, auth=True)
    r = httpx.post(
        f"https://api.github.com/repos/{repo}/pulls",
        headers={"Authorization": f"Bearer {settings.github_token}",
                 "Accept": "application/vnd.github+json"},
        json={"title": title[:72], "head": branch, "base": base, "body": body},
        timeout=30,
    )
    if r.status_code >= 300:
        raise RuntimeError(f"创建 PR 失败: {r.status_code} {r.text[:300]}")
    return r.json()["html_url"]


def cleanup(repo: str, wt: Path):
    with _lock_for(repo):
        shutil.rmtree(wt, ignore_errors=True)
        git(["worktree", "prune"], cwd=_bare(repo), check=False)
