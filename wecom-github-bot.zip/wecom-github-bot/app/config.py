import os
from dataclasses import dataclass, field


def _list(name: str) -> list[str]:
    return [x.strip() for x in os.getenv(name, "").split(",") if x.strip()]


@dataclass
class Settings:
    # 企微智能机器人(API 模式)
    wecom_token: str = os.getenv("WECOM_TOKEN", "")
    wecom_aes_key: str = os.getenv("WECOM_ENCODING_AES_KEY", "")
    # GitHub
    github_token: str = os.getenv("GITHUB_TOKEN", "")
    default_repo: str = os.getenv("DEFAULT_REPO", "")  # owner/name
    allowed_repos: list[str] = field(default_factory=lambda: _list("ALLOWED_REPOS"))
    allowed_users: list[str] = field(default_factory=lambda: _list("ALLOWED_USERS"))  # 企微 userid,留空=所有人
    git_user_name: str = os.getenv("GIT_USER_NAME", "wecom-bot")
    git_user_email: str = os.getenv("GIT_USER_EMAIL", "wecom-bot@users.noreply.github.com")
    # Agent
    claude_bin: str = os.getenv("CLAUDE_BIN", "claude")
    claude_model: str = os.getenv("CLAUDE_MODEL", "")
    task_timeout: int = int(os.getenv("TASK_TIMEOUT_SEC", "1800"))
    workers: int = int(os.getenv("WORKERS", "2"))
    # 存储
    data_dir: str = os.getenv("DATA_DIR", "/data")


settings = Settings()
